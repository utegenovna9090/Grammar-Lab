/* Grammar Lab — нәтижелерді Google Sheets-ке сақтайтын сервер (Google Apps Script) */
var PASS = "Igisat1515"; // мұғалімнің құпиясөзі (платформадағымен бірдей болуы керек)

function sheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName("data");
  if (!sh) {
    sh = ss.insertSheet("data");
    sh.appendRow(["id", "json", "Аты-жөні", "Топ", "Ұпай", "Соңғы кіру"]);
  }
  return sh;
}
function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    var d = JSON.parse(e.postData.contents);
    if (d.act !== "put" || !d.s || !d.s.id) return out_({ ok: 0 });
    var sh = sheet_(), ids = sh.getRange(1, 1, sh.getLastRow(), 1).getValues(), row = -1;
    for (var i = 1; i < ids.length; i++) if (ids[i][0] === d.s.id) { row = i + 1; break; }
    var rec = [d.s.id, JSON.stringify(d.s), d.s.name, d.s.grp, d.s.pts, new Date()];
    if (row < 0) sh.appendRow(rec); else sh.getRange(row, 1, 1, 6).setValues([rec]);
    return out_({ ok: 1 });
  } finally { lock.releaseLock(); }
}
function doGet(e) {
  if (e.parameter.key !== PASS) return out_({ ok: 0 });
  var rows = sheet_().getDataRange().getValues(), list = [];
  for (var i = 1; i < rows.length; i++) list.push(JSON.parse(rows[i][1]));
  return out_({ ok: 1, list: list });
}
